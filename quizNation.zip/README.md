## QuizK ❔✅

### Imagens do projeto:
<img src="https://user-images.githubusercontent.com/100402549/230278000-670ffb28-2bd1-44e0-a225-86237765ffde.png" align="center" />
<img src="https://user-images.githubusercontent.com/100402549/230278193-76828235-7e5e-496f-abdb-960877514b3f.png" align="center" />

&nbsp;

## 💜 Tecnologias/Ferramentas utilizadas

* React
* TypeScript
* Vite
* Styled Components
* React Router

&nbsp;

### 💜 Link para o projeto online
* [QuizK](https://quizk.vercel.app/)

&nbsp;

<p align="center">Feito com 💜 por KauDev</p>
