export const theme = {
  black: "#010109",
  white: "#FFFFFF",
  green: "#32E3AF",
  input: "#222222",
  card: "#26283A",
  cardHover: "#31334A",
  red: "#FF5353",
};
